// Service Worker for Shopee Scraper Extension
let apiEndpoint = 'http://localhost:8000/api';
let syncInterval = 5 * 60 * 1000; // 5 minutes
let isAutoSyncEnabled = true;

// Load settings from storage
chrome.storage.local.get(['apiEndpoint', 'syncInterval', 'autoSync'], (result) => {
    if (result.apiEndpoint) apiEndpoint = result.apiEndpoint;
    if (result.syncInterval) syncInterval = result.syncInterval;
    if (result.autoSync !== undefined) isAutoSyncEnabled = result.autoSync;
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'SHOPEE_DATA') {
        syncDataToDashboard(message.data)
            .then(() => {
                sendResponse({ success: true });
                updateBadge('✓', '#4CAF50');
            })
            .catch((error) => {
                console.error('Sync failed:', error);
                sendResponse({ success: false, error: error.message });
                updateBadge('✗', '#F44336');
            });
        return true; // Keep channel open for async response
    }

    if (message.type === 'GET_STATUS') {
        chrome.storage.local.get(['lastSync', 'totalSynced'], (result) => {
            sendResponse({
                connected: true,
                lastSync: result.lastSync || null,
                totalSynced: result.totalSynced || 0,
                apiEndpoint: apiEndpoint
            });
        });
        return true;
    }

    if (message.type === 'MANUAL_SYNC') {
        // Trigger content script to scrape
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, { type: 'SCRAPE_NOW' });
            }
        });
        sendResponse({ success: true });
    }
});

// Sync data to dashboard API
async function syncDataToDashboard(data) {
    const response = await fetch(`${apiEndpoint}/shopee-data/sync`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    });

    if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
    }

    // Update stats
    chrome.storage.local.get(['totalSynced'], (result) => {
        const newTotal = (result.totalSynced || 0) + 1;
        chrome.storage.local.set({
            lastSync: new Date().toISOString(),
            totalSynced: newTotal
        });
    });

    return response.json();
}

// Update extension badge
function updateBadge(text, color) {
    chrome.action.setBadgeText({ text });
    chrome.action.setBadgeBackgroundColor({ color });

    // Clear badge after 3 seconds
    setTimeout(() => {
        chrome.action.setBadgeText({ text: '' });
    }, 3000);
}

// Auto-sync timer (if enabled)
setInterval(() => {
    if (isAutoSyncEnabled) {
        chrome.tabs.query({ url: '*://*.shopee.co.id/*' }, (tabs) => {
            tabs.forEach(tab => {
                chrome.tabs.sendMessage(tab.id, { type: 'SCRAPE_NOW' });
            });
        });
    }
}, syncInterval);

console.log('Shopee Scraper Extension loaded');
